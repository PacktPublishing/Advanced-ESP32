#include "Arduino.h"

extern uint32_t ulp_entry;
extern uint32_t ulp_sample_counter;
extern uint32_t ulp_low_threshold;
extern uint32_t ulp_high_threshold;
extern uint32_t ulp_ADC_reading;
